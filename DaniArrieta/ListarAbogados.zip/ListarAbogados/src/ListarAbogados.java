

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

/**
 * Servlet implementation class ListarAbogados
 */
@WebServlet("/ListarAbogados")
public class ListarAbogados extends HttpServlet {
	
	ArrayList<Abogado> listaAbogados = new ArrayList();
	Gson gson = new Gson();
	
	private static final long serialVersionUID = 1L;
	
	public void init(ServletConfig config) throws ServletException{
		
		Abogado abogado = new Abogado("Paco","Calle falsa 123","000001",true);
		Abogado abogado2 = new Abogado("Paco2","Calle falsa 124","000002",true);
		Abogado abogado3 = new Abogado("Paco3","Calle falsa 125","000003",true);
		Abogado abogado4 = new Abogado("Paco4","Calle falsa 126","000004",false);
		
		listaAbogados.add(abogado);
		listaAbogados.add(abogado2);
		listaAbogados.add(abogado3);
		listaAbogados.add(abogado4);
	}
	
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ListarAbogados() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String jsonAbogado = "";
		
		//Indicamos que la salida ser� de tipo json.
		response.setContentType("application/json");
		
		
		PrintWriter pw = response.getWriter();
		pw.println(gson.toJson(listaAbogados));
		
		//Recorremos lista de abogados
		/*
		for(int i = 0; i<listaAbogados.size();i++){
			jsonAbogado = gson.toJson(listaAbogados.get(i));
			gson.toJsonTree(src)
		}*/
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Abogado abogado = new Abogado("PacoNuevo","Calle falsa 123","000001",true);
		listaAbogados.add(abogado);
	}
	
	protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		BufferedReader br = request.getReader();
		String mensajeBody = br.readLine();
		
		listaAbogados.remove(Integer.parseInt(mensajeBody));
		
		PrintWriter pw = response.getWriter();
		pw.println(gson.toJson(listaAbogados));
	}
	
	protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		BufferedReader br = request.getReader();
		String mensajeBody = br.readLine();
		
		String[] entrada = mensajeBody.split(";");
		
		PrintWriter pw = response.getWriter();
		pw.println("Modifica Abogados");
	}

}
