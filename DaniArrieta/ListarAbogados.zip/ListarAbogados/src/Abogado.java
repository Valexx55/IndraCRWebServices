
public class Abogado {
	
	private String nombre;
	private String direccion;
	private String licencia;
	private boolean colegiado;
	
	public Abogado(String nombre, String direccion, String licencia, boolean colegiado) {
		super();
		this.nombre = nombre;
		this.direccion = direccion;
		this.licencia = licencia;
		this.colegiado = colegiado;
	}
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public String getLicencia() {
		return licencia;
	}
	public void setLicencia(String licencia) {
		this.licencia = licencia;
	}
	public boolean isColegiado() {
		return colegiado;
	}
	public void setColegiado(boolean colegiado) {
		this.colegiado = colegiado;
	}

	@Override
	public String toString() {
		return "Abogado [nombre=" + nombre + ", direccion=" + direccion + ", licencia=" + licencia + ", colegiado="
				+ colegiado + "]";
	}
	
	
	

}
