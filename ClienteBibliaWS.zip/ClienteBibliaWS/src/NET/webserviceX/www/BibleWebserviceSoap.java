/**
 * BibleWebserviceSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package NET.webserviceX.www;

public interface BibleWebserviceSoap extends java.rmi.Remote {

    /**
     * This web service list all versus by Book Title ,Chapter and
     * Verse from the Kings James version Bible
     */
    public java.lang.String getBibleWordsByChapterAndVerse(java.lang.String bookTitle, int chapter, int verse) throws java.rmi.RemoteException;

    /**
     * This web service list all versus by keyword from the Kings
     * James version Bible
     */
    public java.lang.String getBibleWordsbyKeyWord(java.lang.String bibleWords) throws java.rmi.RemoteException;

    /**
     * This web service list all books from the Kings James version
     * Bible
     */
    public java.lang.String getBookTitles() throws java.rmi.RemoteException;

    /**
     * This web service list all versus by Book Title and Chapter
     * from the Kings James version Bible
     */
    public java.lang.String getBibleWordsByBookTitleAndChapter(java.lang.String bookTitle, int chapter) throws java.rmi.RemoteException;
}
