package NET.webserviceX.www;

public class BibleWebserviceSoapProxy implements NET.webserviceX.www.BibleWebserviceSoap {
  private String _endpoint = null;
  private NET.webserviceX.www.BibleWebserviceSoap bibleWebserviceSoap = null;
  
  public BibleWebserviceSoapProxy() {
    _initBibleWebserviceSoapProxy();
  }
  
  public BibleWebserviceSoapProxy(String endpoint) {
    _endpoint = endpoint;
    _initBibleWebserviceSoapProxy();
  }
  
  private void _initBibleWebserviceSoapProxy() {
    try {
      bibleWebserviceSoap = (new NET.webserviceX.www.BibleWebserviceLocator()).getBibleWebserviceSoap();
      if (bibleWebserviceSoap != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)bibleWebserviceSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)bibleWebserviceSoap)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (bibleWebserviceSoap != null)
      ((javax.xml.rpc.Stub)bibleWebserviceSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public NET.webserviceX.www.BibleWebserviceSoap getBibleWebserviceSoap() {
    if (bibleWebserviceSoap == null)
      _initBibleWebserviceSoapProxy();
    return bibleWebserviceSoap;
  }
  
  public java.lang.String getBibleWordsByChapterAndVerse(java.lang.String bookTitle, int chapter, int verse) throws java.rmi.RemoteException{
    if (bibleWebserviceSoap == null)
      _initBibleWebserviceSoapProxy();
    return bibleWebserviceSoap.getBibleWordsByChapterAndVerse(bookTitle, chapter, verse);
  }
  
  public java.lang.String getBibleWordsbyKeyWord(java.lang.String bibleWords) throws java.rmi.RemoteException{
    if (bibleWebserviceSoap == null)
      _initBibleWebserviceSoapProxy();
    return bibleWebserviceSoap.getBibleWordsbyKeyWord(bibleWords);
  }
  
  public java.lang.String getBookTitles() throws java.rmi.RemoteException{
    if (bibleWebserviceSoap == null)
      _initBibleWebserviceSoapProxy();
    return bibleWebserviceSoap.getBookTitles();
  }
  
  public java.lang.String getBibleWordsByBookTitleAndChapter(java.lang.String bookTitle, int chapter) throws java.rmi.RemoteException{
    if (bibleWebserviceSoap == null)
      _initBibleWebserviceSoapProxy();
    return bibleWebserviceSoap.getBibleWordsByBookTitleAndChapter(bookTitle, chapter);
  }
  
  
}