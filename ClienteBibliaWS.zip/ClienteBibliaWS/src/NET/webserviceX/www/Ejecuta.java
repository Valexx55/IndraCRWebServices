package NET.webserviceX.www;

import java.rmi.RemoteException;

public class Ejecuta {

	public static void main(String[] args) {
		 BibleWebserviceSoap b = new BibleWebserviceSoapProxy();
		  try {
			//System.out.println(b.getBibleWordsbyKeyWord("Water"));  
			System.out.println(b.getBookTitles());
		} catch (RemoteException e) {
		}
	}

}
