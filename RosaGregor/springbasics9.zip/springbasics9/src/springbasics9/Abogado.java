package springbasics9;

public class Abogado
{

   private String nombre;
   private boolean colegiado;
   private String licencia;
   private String direccion;
   
   
   
    public Abogado(String nombre, boolean colegiado, String licencia, String direccion) {
	super();
	this.nombre = nombre;
	this.colegiado = colegiado;
	this.licencia = licencia;
	this.direccion = direccion;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public boolean isColegiado() {
		return colegiado;
	}
	public void setColegiado(boolean colegiado) {
		this.colegiado = colegiado;
	}
	public String getLicencia() {
		return licencia;
	}
	public void setLicencia(String licencia) {
		this.licencia = licencia;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	@Override
	public String toString() {
		return "Abogado [nombre=" + nombre + ", colegiado=" + colegiado + ", licencia=" + licencia + ", direccion="
				+ direccion + "]";
	}
   
   
   
	 
}
